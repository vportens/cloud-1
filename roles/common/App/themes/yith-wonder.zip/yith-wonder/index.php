<?php
/**
 * Index.php file of the theme.
 *
 * @package yith-wonder
 * @since 1.0.0
 */

// Silence is golden.
